from typing import List, Tuple

Headers = List[Tuple[bytes, bytes]]